# M365 Admin Toolkit Lite

Free PowerShell reporting tools for Microsoft 365 and Exchange Online administrators.

This is the **Lite edition** of M365 Admin Toolkit Pro.

## Included tools

| Script | Purpose |
|---|---|
| `Export-AcceptedDomains.ps1` | Export Exchange Online accepted domains |
| `Export-DistributionGroupsByKeyword.ps1` | Find distribution groups by keyword |
| `Export-MailboxAliases.ps1` | Export secondary SMTP aliases |
| `Export-MailboxHealth.ps1` | Export mailbox size, item-count, archive, and quota information |

## Requirements

- PowerShell 7 recommended
- Microsoft 365 administrative account
- ExchangeOnlineManagement module
- Appropriate Exchange Online permissions

Install the Exchange Online module:

```powershell
Install-Module ExchangeOnlineManagement -Scope CurrentUser
```

## Example

```powershell
.\Scripts\Export-AcceptedDomains.ps1
```

For a distribution-group keyword search:

```powershell
.\Scripts\Export-DistributionGroupsByKeyword.ps1 -Keywords "expedite","next"
```

## Pro edition

Need more than basic inventory reporting?

**M365 Admin Toolkit Pro** adds:

- Interactive admin console
- Distribution-group governance
- Microsoft 365 Group owner reporting
- Mailbox permission reporting
- Archive mailbox monitoring
- Message tracing with `Get-MessageTraceV2`
- Teams external-access reporting
- External-domain review
- Unified Audit Log exports
- Mailbox audit activity
- Teams meeting audit reporting
- HTML tenant health summary
- Commercial-use documentation

**Get M365 Admin Toolkit Pro:**  
`Toolkit Pro`

## Safety

These Lite-edition scripts are intended to be read-only reporting tools.

Review all PowerShell code before using it in a production Microsoft 365 environment.

## Disclaimer

This is an independent project and is not affiliated with or endorsed by Microsoft.

Microsoft 365 services, PowerShell cmdlets, APIs, permissions, and licensing can change over time.

## License

The Lite edition is released under the MIT License. See `LICENSE`.

