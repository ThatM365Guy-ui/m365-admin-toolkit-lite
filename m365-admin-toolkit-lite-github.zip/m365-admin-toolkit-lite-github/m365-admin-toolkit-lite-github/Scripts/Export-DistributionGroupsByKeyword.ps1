[CmdletBinding()]
param(
    [Parameter(Mandatory=$true)]
    [string[]]$Keywords,

    [string]$OutFile = (Join-Path $PSScriptRoot "..\Output\DistributionGroups_ByKeyword.csv")
)

$ErrorActionPreference = "Stop"
Connect-ExchangeOnline -ShowBanner:$false

$OutFile = [IO.Path]::GetFullPath($OutFile)
New-Item -ItemType Directory -Path (Split-Path $OutFile -Parent) -Force | Out-Null

$Groups = @(Get-DistributionGroup -ResultSize Unlimited)
$Results = foreach ($Group in $Groups) {
    $SearchText = @(
        $Group.DisplayName
        $Group.Name
        $Group.Alias
        $Group.PrimarySmtpAddress
    ) -join " "

    $Matched = @($Keywords | Where-Object { $SearchText -like "*$_*" })

    if ($Matched.Count -gt 0) {
        [pscustomobject]@{
            DisplayName          = $Group.DisplayName
            Name                 = $Group.Name
            Alias                = $Group.Alias
            PrimarySmtpAddress   = $Group.PrimarySmtpAddress
            RecipientTypeDetails = $Group.RecipientTypeDetails
            GroupType            = $Group.GroupType
            ManagedBy            = ($Group.ManagedBy -join "; ")
            MatchedKeywords      = ($Matched -join "; ")
        }
    }
}

$Results = @($Results | Sort-Object DisplayName)
$Results | Export-Csv $OutFile -NoTypeInformation -Encoding UTF8
Write-Host "Found $($Results.Count) matching groups. Export: $OutFile" -ForegroundColor Green
