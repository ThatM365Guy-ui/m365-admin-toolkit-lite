[CmdletBinding()]
param(
    [string]$OutFile = (Join-Path $PSScriptRoot "..\Output\MailboxAliases.csv")
)

$ErrorActionPreference = "Stop"
Connect-ExchangeOnline -ShowBanner:$false

$OutFile = [IO.Path]::GetFullPath($OutFile)
New-Item -ItemType Directory -Path (Split-Path $OutFile -Parent) -Force | Out-Null

$Mailboxes = @(Get-EXOMailbox -ResultSize Unlimited -Properties EmailAddresses,DisplayName,PrimarySmtpAddress)
$Results = [System.Collections.Generic.List[object]]::new()

foreach ($Mailbox in $Mailboxes) {
    foreach ($Address in $Mailbox.EmailAddresses) {
        $AddressText = [string]$Address
        if ($AddressText -clike "smtp:*") {
            $Results.Add([pscustomobject]@{
                DisplayName=$Mailbox.DisplayName
                PrimarySmtpAddress=$Mailbox.PrimarySmtpAddress
                Alias=$AddressText.Substring(5)
            })
        }
    }
}

$Results | Sort-Object PrimarySmtpAddress,Alias | Export-Csv $OutFile -NoTypeInformation -Encoding UTF8
Write-Host "Exported $($Results.Count) aliases to $OutFile" -ForegroundColor Green
