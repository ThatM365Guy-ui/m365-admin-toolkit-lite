[CmdletBinding()]
param(
    [string]$OutFile = (Join-Path $PSScriptRoot "..\Output\AcceptedDomains.csv")
)

$ErrorActionPreference = "Stop"
Connect-ExchangeOnline -ShowBanner:$false

$OutFile = [IO.Path]::GetFullPath($OutFile)
New-Item -ItemType Directory -Path (Split-Path $OutFile -Parent) -Force | Out-Null

$Results = Get-AcceptedDomain -ResultSize Unlimited |
    Sort-Object DomainName |
    Select-Object Name,DomainName,DomainType,Default,MatchSubDomains

$Results | Export-Csv $OutFile -NoTypeInformation -Encoding UTF8
Write-Host "Exported $(@($Results).Count) accepted domains to $OutFile" -ForegroundColor Green
