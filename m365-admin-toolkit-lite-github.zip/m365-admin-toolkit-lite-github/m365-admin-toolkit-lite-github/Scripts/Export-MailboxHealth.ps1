[CmdletBinding()]
param(
    [string]$OutFile = (Join-Path $PSScriptRoot "..\Output\MailboxHealth.csv")
)

$ErrorActionPreference = "Stop"
Connect-ExchangeOnline -ShowBanner:$false

function Convert-SizeToGB {
    param($Size)
    if ($null -eq $Size) { return $null }
    $Text = [string]$Size
    if ($Text -match '\(([\d,]+) bytes\)') {
        return [math]::Round(([double]($matches[1] -replace ',','') / 1GB),2)
    }
    return $null
}

$OutFile = [IO.Path]::GetFullPath($OutFile)
New-Item -ItemType Directory -Path (Split-Path $OutFile -Parent) -Force | Out-Null

$Mailboxes = @(Get-EXOMailbox -ResultSize Unlimited -Properties DisplayName,PrimarySmtpAddress,RecipientTypeDetails,ArchiveStatus,IssueWarningQuota,ProhibitSendQuota,ProhibitSendReceiveQuota)
$Results = [System.Collections.Generic.List[object]]::new()

for ($i=0; $i -lt $Mailboxes.Count; $i++) {
    $Mailbox = $Mailboxes[$i]
    Write-Progress -Activity "Collecting mailbox health" -Status "$($i+1) of $($Mailboxes.Count): $($Mailbox.PrimarySmtpAddress)" -PercentComplete ((($i+1)/$Mailboxes.Count)*100)

    try {
        $Stats = Get-EXOMailboxStatistics -Identity $Mailbox.PrimarySmtpAddress -Properties LastLogonTime,ItemCount,TotalItemSize,DeletedItemCount,TotalDeletedItemSize
        $Results.Add([pscustomobject]@{
            DisplayName=$Mailbox.DisplayName
            PrimarySmtpAddress=$Mailbox.PrimarySmtpAddress
            RecipientTypeDetails=$Mailbox.RecipientTypeDetails
            ArchiveStatus=$Mailbox.ArchiveStatus
            ItemCount=$Stats.ItemCount
            MailboxSizeGB=(Convert-SizeToGB $Stats.TotalItemSize)
            DeletedItemCount=$Stats.DeletedItemCount
            DeletedItemSizeGB=(Convert-SizeToGB $Stats.TotalDeletedItemSize)
            LastLogonTime=$Stats.LastLogonTime
            IssueWarningQuota=$Mailbox.IssueWarningQuota
            ProhibitSendQuota=$Mailbox.ProhibitSendQuota
            ProhibitSendReceiveQuota=$Mailbox.ProhibitSendReceiveQuota
        })
    } catch {
        Write-Warning "Failed mailbox health lookup for $($Mailbox.PrimarySmtpAddress): $($_.Exception.Message)"
    }
}

Write-Progress -Activity "Collecting mailbox health" -Completed
$Results | Sort-Object MailboxSizeGB -Descending | Export-Csv $OutFile -NoTypeInformation -Encoding UTF8
Write-Host "Mailbox health export complete: $OutFile" -ForegroundColor Green
