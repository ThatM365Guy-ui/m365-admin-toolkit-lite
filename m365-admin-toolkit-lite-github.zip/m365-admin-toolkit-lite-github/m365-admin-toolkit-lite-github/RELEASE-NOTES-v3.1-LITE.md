# M365 Admin Toolkit Lite v3.1

Initial public Lite release.

Includes four read-only Exchange Online reporting tools:
- Accepted domains
- Distribution-group keyword search
- Mailbox aliases
- Mailbox health reporting
