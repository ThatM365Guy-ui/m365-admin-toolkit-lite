# Security

Do not include Microsoft 365 credentials, tokens, certificates, tenant-specific exports, or customer data when opening an issue or sharing diagnostic information.

If you believe you found a security issue in the scripts, do not publish credentials or production data in a public GitHub issue.
