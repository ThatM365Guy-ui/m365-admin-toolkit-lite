# Contributing

Bug reports and improvement suggestions are welcome.

When submitting an issue:
- Include the script name.
- Include your PowerShell version.
- Include the relevant Microsoft module version.
- Remove tenant names, email addresses, IDs, tokens, and other confidential information.
